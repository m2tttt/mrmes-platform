import os
import asyncio
import yt_dlp
import sqlite3
from datetime import datetime, date, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

TOKEN = "8752863537:AAHa9i10hVYK7L5OhUoCKLO2az38YOqk1NE" # توكن البوت
ADMIN_USER_ID = 7357356505 # معرف المسؤول (محمد رمضان)
DATABASE_NAME = 'mrmes_bot.db'
MAX_FREE_REQUESTS = 5 # الحد الأقصى للطلبات المجانية يومياً

# --- Database Functions ---
def get_db_connection():
    conn = sqlite3.connect(DATABASE_NAME)
    conn.row_factory = sqlite3.Row # لتمكين الوصول إلى الأعمدة بالاسم
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id BIGINT PRIMARY KEY,
            is_pro BOOLEAN DEFAULT FALSE,
            subscription_expires TIMESTAMP,
            requests_today INT DEFAULT 0,
            last_request DATE DEFAULT CURRENT_DATE
        );
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS subscription_requests (
            id TEXT PRIMARY KEY,
            user_id BIGINT,
            proof_file_id TEXT,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)
    conn.commit()
    conn.close()

def get_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return user

def create_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (id) VALUES (?) RETURNING *", (user_id,))
    user = cursor.fetchone()
    conn.commit()
    conn.close()
    return user

def update_user_request_count(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    today = date.today()
    user = get_user(user_id)

    if user and user['last_request'] != str(today):
        # Reset requests if it's a new day
        cursor.execute("UPDATE users SET requests_today = 1, last_request = ? WHERE id = ?", (today, user_id))
    else:
        cursor.execute("UPDATE users SET requests_today = requests_today + 1 WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()

def is_pro_user(user_id):
    user = get_user(user_id)
    if user and user['is_pro'] and user['subscription_expires'] and datetime.fromisoformat(user['subscription_expires']) > datetime.now():
        return True
    return False

def get_remaining_requests(user_id):
    user = get_user(user_id)
    if not user:
        return MAX_FREE_REQUESTS
    
    today = date.today()
    if user['last_request'] != str(today):
        return MAX_FREE_REQUESTS
    
    return MAX_FREE_REQUESTS - user['requests_today']

# --- Bot Commands ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user = get_user(user_id)
    if not user:
        user = create_user(user_id)

    welcome_message = (
        "مرحباً بك في MRMES Media AI 👑\n\n"
        "بوت احترافي لتنزيل الفيديوهات من جميع منصات التواصل الاجتماعي.\n"
        "طريقة الاستخدام: أرسل الرابط فقط وسيتم التحميل فوراً.\n\n"
    )

    if is_pro_user(user_id):
        welcome_message += "أنت مشترك Pro! استمتع بتحميلات غير محدودة. ✨"
    else:
        remaining = get_remaining_requests(user_id)
        welcome_message += f"لديك {remaining} طلب تحميل مجاني متبقي اليوم. 🆓\n"
        welcome_message += "للاشتراك في خدمة Pro والحصول على تحميلات غير محدودة، استخدم أمر /subscribe."

    await update.message.reply_text(welcome_message)

async def download_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user = get_user(user_id)
    if not user:
        user = create_user(user_id)

    if not is_pro_user(user_id):
        remaining = get_remaining_requests(user_id)
        if remaining <= 0:
            await update.message.reply_text(
                "عذراً، لقد استنفدت عدد التحميلات المجانية اليوم. 😔\n"
                "للاشتراك في خدمة Pro والحصول على تحميلات غير محدودة، استخدم أمر /subscribe."
            )
            return
        update_user_request_count(user_id)

    url = update.message.text
    if not url.startswith("http"):
        return

    status_message = await update.message.reply_text("جاري معالجة الرابط والتحميل... ⏳")

    ydl_opts = {
        'format': 'best',
        'outtmpl': 'downloads/%(title)s.%(ext)s',
        'max_filesize': 50 * 1024 * 1024, # تحديد الحجم بـ 50 ميجا لتجنب قيود تليجرام
    }

    try:
        if not os.path.exists('downloads'):
            os.makedirs('downloads')

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            filename = ydl.prepare_filename(info)

        await status_message.edit_text("جاري إرسال الفيديو... 📤")
        
        with open(filename, 'rb') as video_file:
            await update.message.reply_video(video=video_file, caption=f"تم التحميل بواسطة MRMES Media AI 👑\n\n{info.get('title', '')}")

        await status_message.delete()
        os.remove(filename)

    except Exception as e:
        await status_message.edit_text(f"عذراً، حدث خطأ أثناء التحميل: {str(e)}")
        if os.path.exists(filename):
            os.remove(filename)

async def subscribe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if is_pro_user(user_id):
        await update.message.reply_text("أنت بالفعل مشترك Pro! ✨")
        return

    await update.message.reply_text(
        "للاشتراك في خدمة Pro والحصول على تحميلات غير محدودة:\n\n"
        "1. قم بتحويل مبلغ الاشتراك (مثلاً 10$ شهرياً) إلى هذا الحساب: `your_payment_account_id` (استبدل هذا بمعرف حساب الدفع الخاص بك)\n"
        "2. أرسل لي لقطة شاشة (screenshot) أو إثبات الدفع كصورة.\n"
        "3. سأقوم بمراجعة طلبك وتفعيل اشتراكك في أقرب وقت ممكن. شكراً لك!"
    )

async def handle_proof(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if update.message.photo:
        proof_file_id = update.message.photo[-1].file_id
        request_id = f"req_{user_id}_{datetime.now().timestamp()}"
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO subscription_requests (id, user_id, proof_file_id) VALUES (?, ?, ?)",
                       (request_id, user_id, proof_file_id))
        conn.commit()
        conn.close()

        await update.message.reply_text("تم استلام إثبات الدفع الخاص بك بنجاح! سيتم مراجعته قريباً. 🙏")
        
        # Notify admin
        if ADMIN_USER_ID:
            keyboard = [
                [InlineKeyboardButton("قبول ✅", callback_data=f"approve_{user_id}")],
                [InlineKeyboardButton("رفض ❌", callback_data=f"reject_{user_id}")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await context.bot.send_photo(chat_id=ADMIN_USER_ID, photo=proof_file_id,
                                         caption=f"طلب اشتراك جديد من المستخدم {user_id}.",
                                         reply_markup=reply_markup)
    else:
        await update.message.reply_text("الرجاء إرسال إثبات الدفع كصورة.")

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if not query.from_user.id == ADMIN_USER_ID:
        await query.edit_message_text("ليس لديك صلاحية للقيام بهذا الإجراء.")
        return

    action, target_user_id = data.split('_')
    target_user_id = int(target_user_id)

    conn = get_db_connection()
    cursor = conn.cursor()

    if action == "approve":
        # Activate Pro subscription for 30 days
        expires = datetime.now() + timedelta(days=30)
        cursor.execute("UPDATE users SET is_pro = TRUE, subscription_expires = ? WHERE id = ?", (expires, target_user_id))
        conn.commit()
        await query.edit_message_text(f"تم تفعيل اشتراك Pro للمستخدم {target_user_id} لمدة 30 يوماً. ✅")
        await context.bot.send_message(chat_id=target_user_id, text="تهانينا! تم تفعيل اشتراكك Pro بنجاح. استمتع بتحميلات غير محدودة! 🎉")
    elif action == "reject":
        await query.edit_message_text(f"تم رفض طلب الاشتراك للمستخدم {target_user_id}. ❌")
        await context.bot.send_message(chat_id=target_user_id, text="عذراً، تم رفض طلب اشتراكك Pro. يرجى التواصل مع الدعم للمزيد من المعلومات.")
    
    # Update request status in DB (optional, but good practice)
    cursor.execute("UPDATE subscription_requests SET status = ? WHERE user_id = ? AND status = 'pending'", (action, target_user_id))
    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db() # تهيئة قاعدة البيانات عند بدء تشغيل البوت
    from telegram.request import HTTPXRequest
    request = HTTPXRequest(connect_timeout=20, read_timeout=20)
    application = ApplicationBuilder().token(TOKEN).request(request).build()
    
    start_handler = CommandHandler('start', start)
    subscribe_handler = CommandHandler('subscribe', subscribe)
    message_handler = MessageHandler(filters.TEXT & (~filters.COMMAND), download_video)
    photo_handler = MessageHandler(filters.PHOTO, handle_proof)
    button_handler = MessageHandler(filters.CallbackQuery(), button_callback)

    application.add_handler(start_handler)
    application.add_handler(subscribe_handler)
    application.add_handler(message_handler)
    application.add_handler(photo_handler)
    application.add_handler(button_handler)
    
    print("البوت يعمل الآن...")
    application.run_polling()
